module at.spengergasse.projekt_clicker {
    requires javafx.controls;
    requires javafx.fxml;


    opens at.spengergasse.projekt_clicker to javafx.fxml;
    exports at.spengergasse.projekt_clicker;
}